package com.example.bidding_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiddingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
