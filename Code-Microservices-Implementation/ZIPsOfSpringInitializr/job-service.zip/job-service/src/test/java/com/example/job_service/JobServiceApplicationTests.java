package com.example.job_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
